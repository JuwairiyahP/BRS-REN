from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.shaders import lit_with_shadows_shader
import numpy as np
import random

from info import *

able_text=True
def sol_info():
    
    global able_text
    app = Ursina(borderless=False)
    
    window.title = 'Ursina Solar System Simulation'
    window.fps_counter.enabled = True
    fps = 30
    window.fps_counter.max = 30
    window.exit_button.enabled=False
    
    
    music = Audio(sound_file_name='hb/music.mp3', loop=True, autoplay=True, volume=3)
    
    able_text = True
    paused = False
    
    
    
    info_of_planets=[Sun_info,Mercury_info,Venus_info,Earth_info,Mars_info,Jupiter_info,Saturn_info,Uranus_info,Neptune_info]
    
    class Planet(Entity):
    
        def __init__(self, x, y, z, scale, texture, name):
            super().__init__()
            self.model = 'sphere'
            self.collider = 'sphere'
            self.x = x
            self.y = y
            self.z = z
            self.scale = scale
            self.shader = lit_with_shadows_shader
            self.texture = texture
            self.name = name
            self.sun = False
    
        # Displays Name of the planet on the screen
        def input(self, key):
            def text_abler():
                global able_text
                able_text = True
            global paused, able_text
            if self.hovered and able_text:
                name_text = Text(text=self.name,scale=0.75)
                able_text = False
                name_text.appear(speed=0.01)
                destroy(name_text, delay=20)
                invoke(text_abler, delay=20)
    
    
    sun = Planet(0, 0, 0, 280, 'hb/sun.jpg',Sun_info)
    
    earth = Planet(370,0,0, 10, 'hb/earth.jpg',Earth_info)
    
    mars = Planet(430,0,0, 6, 'hb/mars.jpg',Mars_info)
    
    mercury = Planet(250,0,0,5,'hb/mercury.jpg',Mercury_info)
    
    venus = Planet(300,0,0, 10, 'hb/venus.jpg',Venus_info)
    
    jupiter = Planet(570,0,0, 40, 'hb/jupiter.jpg',Jupiter_info)
    
    saturn = Planet(670,0,0, 45, 'hb/saturn.jpg',Saturn_info)
    
    
    uranus = Planet(750,0,0,37.5, 'hb/uranus.jpg',Uranus_info)
    
    neptune = Planet(820,0,0, 30, 'hb/neptune.jpg',Neptune_info)
        
    x=rad=500
    z=0
    #for i in range(1000):
    while x>0 and z!=500:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(x,0,z))
        x-=5
        z=math.sqrt(250000-x**2)
    while x>-490 and z!=0:
        Asteroid=Entity(model='sphere',texture='hb/steroid.jpg',scale=1.5,position=Vec3(x,0,z))
        x-=5
        z=math.sqrt(250000-x**2)
    while x<0 and z!=-500:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(x,0,z))
        x+=5
        z=-(math.sqrt(250000-x**2))
    
    while x<500 and z!=0:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(x,0,z))
        x+=5
        z=-(math.sqrt(250000-x**2))
        
    
    p=500
    q=0 
    while p>0 and q!=500:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(p,0,q))
        p-=5
        q=math.sqrt(250000-p**2)
    while p>-490 and q!=0:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(p,0,q))
        p-=5
        q=math.sqrt(250000-p**2)
    while p<0 and q!=-500:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(p,0,q))
        p+=5
        q=-(math.sqrt(250000-p**2))
    
    while p<500 and q!=0:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(p,0,q))
        p+=5
        q=-(math.sqrt(250000-p**2))
        
    r=500
    s=0 
    while s>0 and r!=500:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(s,0,r))
        s-=5
        r=math.sqrt(250000-s**2)
    while s>-490 and r!=0:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(s,0,r))
        s-=5
        r=math.sqrt(250000-s**2)
    while s<0 and r!=-500:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(s,0,r))
        s+=5
        r=-(math.sqrt(250000-s**2))
    
    while s<500 and r!=0:
        Asteroid=Entity(model='sphere',texture='hb/asteroid.jpg',scale=1.5,position=Vec3(s,0,r))
        s+=5
        r=-(math.sqrt(250000-p**2))
     
    
    cam=EditorCamera()
    
    cam.rotation_x=90
    bg=Sky()
    bg.texture='hb/space.png'
    
    app.run()
   