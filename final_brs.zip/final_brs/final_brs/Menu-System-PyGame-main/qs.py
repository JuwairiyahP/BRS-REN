from buttons import Button
from emirinfo import *
from quicksilver import *
import sys
import pygame
pygame.init()
SCREEN=pygame.display.set_mode((1280,720))
BG=pygame.transform.scale(pygame.image.load('wp.jpg'),(1280,720))
pixelfont=pygame.font.Font("gothic.ttf",30)
pixelfont1=pygame.font.Font("gothic.ttf",100)
while True:
    SCREEN.blit(BG, (0,0))
    MENU_MOUSE_POS = pygame.mouse.get_pos()
    MENU_TEXT =pixelfont1.render("UAE", True, "Teal")
    MENU_RECT = MENU_TEXT.get_rect(center=(640, 100))
    TIMELINE_BUTTON = Button(image=pygame.image.load("assets/Options Rect.png"), pos=(640, 350), 
                        text_input="Timeline of the UAE", font=pixelfont, base_color="Pink", hovering_color="White")
    EMIRATES_BUTTON = Button(image=pygame.image.load("assets/Options Rect.png"), pos=(640, 500), 
                        text_input="Emirates", font=pixelfont, base_color="Pink", hovering_color="White")

    SCREEN.blit(MENU_TEXT, MENU_RECT)

    for button in [TIMELINE_BUTTON,EMIRATES_BUTTON]:
        button.changeColor(MENU_MOUSE_POS)
        button.update(SCREEN)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if TIMELINE_BUTTON.checkForInput(MENU_MOUSE_POS):
                timeline()
                pygame.quit()
            if EMIRATES_BUTTON.checkForInput(MENU_MOUSE_POS):
                pygame.quit()
    pygame.display.update()
