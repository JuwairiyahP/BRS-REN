auhtxt='''Abu Dhabi, the capital of the United Arab Emirates,
sits off the mainland on an island in the Persian (Arabian) Gulf.'''
dxbtxt='''Dubai is a city and emirate in the United Arab Emirates 
known for luxury shopping, ultramodern architecture and a lively nightlife scene.'''
shjtxt='''Sharjah is the third-most populous city in the United Arab Emirates,
after Dubai and Abu Dhabi'''
ajmtxt='''Ajman is the capital of the emirate of Ajman in the United 
Arab Emirates. It is the fifth-largest city'''
ummtxt='''Umm al-Quwain is one of the United Arab Emirates. 
Umm al-Quwain city lies on the Arabian Gulf.'''
rastxt='''Ras Al Khaimah is the largest city and capital of the Emirate 
of Ras Al Khaimah, United Arab Emirates. It is the sixth-largest city in UAE'''
fujtxt='''Fujairah City is the capital of the emirate of Fujairah in the 
United Arab Emirates. It is the seventh-largest city in UAE'''